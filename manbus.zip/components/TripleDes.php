<?php
namespace app\components;

class TripleDes {

    private static $SECRET = "eZiYIWw0";

    public static function Encrypt($data) {
        //Generate a key from a hash
        $key = md5(utf8_encode(self::$SECRET), true);

        //Take first 8 bytes of $key and append them to the end of $key.
        $key .= substr($key, 0, 8);

        //Pad for PKCS7
        $blockSize = mcrypt_get_block_size('tripledes', 'ecb');
        $len       = strlen($data);
        $pad       = $blockSize - ($len % $blockSize);
        $data .= str_repeat(chr($pad), $pad);

        //Encrypt data
        $encData = mcrypt_encrypt('tripledes', $key, $data, 'ecb');

        return base64_encode($encData);
    }

    public static function Decrypt($data) {

        //Generate a key from a hash
        $key = md5(utf8_encode(self::$SECRET), true);

        //Take first 8 bytes of $key and append them to the end of $key.
        $key .= substr($key, 0, 8);

        $data = base64_decode($data);

        $data = mcrypt_decrypt('tripledes', $key, $data, 'ecb');

        $block = mcrypt_get_block_size('tripledes', 'ecb');
        $len   = strlen($data);
        $pad   = ord($data[$len - 1]);

        return substr($data, 0, strlen($data) - $pad);
    }

}
