<form id="form-modulo">
    <div class="form-group">
        <label>Nombre Módulo<span class="text-danger">*</span></label>
        <input type="text" class="form-control" placeholder="Ingrese nombre del módulo" name="nombre" id="nombre"/>
    </div>
    <div class="form-group">
        <label>Ruta<span class="text-danger">*</span></label>
        <input type="text" class="form-control" placeholder="Ingrese ruta" name="ruta" id="ruta" />
    </div>
    <hr>
    <button class="btn btn-primary mr-2" id="btn-guardar">Guardar</button>
    <a class="btn btn-secondary" id="btn-cancelar">Cancelar</a>
</form>
