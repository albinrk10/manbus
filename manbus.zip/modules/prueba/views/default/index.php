<label>Listado de base de datos</label>
<?php foreach ($datos as $d): ?>
    <h5><?= $d->nombre_prueba ?></h5>
<?php endforeach; ?>
