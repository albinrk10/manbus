<h2><?= $uno ?></h2>
<form method="post" action="nuevo/default/saludo">
    <div class="form-group">
        <label for="exampleInputEmail1">Nombre</label>
        <input type="text" class="form-control" name="nombre">
    </div>

    <button type="submit" class="btn btn-primary">Ejecutar</button>
</form>