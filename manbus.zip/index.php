<?php
header('Location: web/');
