<?php

/* @var $this yii\web\View */

$this->title = 'Manbus';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>¡Bienvenido!</h1>

        <p class="lead">Sistema de mantenimiento de buses - Manbus</p>

    </div>

</div>
